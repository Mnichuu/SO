#ifndef KOLEJKI_H
#define KOLEJKI_H

#define KOLEJKA_NAZWA "/kolejka_komunikatow"
#define MAX_WIADOMOSCI 10
#define DLUGOSC_KOMUNIKATU 30


mqd_t kolejka_utworz (const char *name, int oflag); // tworzy nową kolejkę o podanej nazwie i flagach
mqd_t kolejka_otworz (const char *name, int oflag); 
void kolejka_wyslij (mqd_t mq_des, const char *msg_ptr, unsigned int msg_prio); // wysyla komunikat do kolejki z podanym priorytetem
void kolejka_odbierz (mqd_t mq_des, char *msg_ptr, unsigned int *msg_prio); // odbiera komunikat z podanej kolejki
void kolejka_zamknij (mqd_t mq_des); // zamyka nie używaną już kolejkę
void kolejka_usun (const char *name); // usuwa kolejkę o podanej nazwie
struct mq_attr kolejka_pobierz_atrybuty (mqd_t mq_des); // pobiera atrybuty kolejki

#endif