#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <mqueue.h>
#include "kolejki_komunikatow.h"

mqd_t serwer;

void wyjscie(void) // void do zamykania programu funkcja atexit
{
	kolejka_zamknij (serwer);
}

void sygnal_wyjscie(int signal) // wypisywanie komunikatu z funkcji signal
{
	printf ("\nSygnał przerwania, zamykanie kolejki\n");
	exit(EXIT_SUCCESS);
}

int main () 
{
	
	char kolejka_odpowiedz_nazwa[10];
	mqd_t kolejka_odpowiedz;
	char odczyt[DLUGOSC_KOMUNIKATU];
	char string[DLUGOSC_KOMUNIKATU+10];
	const double max_dlugosc_czekania = 4.0;
	
	sprintf (kolejka_odpowiedz_nazwa, "/%d", getpid());
	
	sleep (1); // czekanie na start serwera
	
	serwer = kolejka_otworz (KOLEJKA_NAZWA, O_WRONLY); // otwieranie kolejki do wysylania do niej komunikatow przez O_WRONLY
	
	//struktura atrybutów, flag, maksymalnego rozmiaru wiadomosci, rozmiar wiadomosci, liczba aktualnych zapytan w kolejce
	{
		struct mq_attr atrybuty = kolejka_pobierz_atrybuty (serwer);
		printf ("Otworzono kolejkę \"%s\" o deskryptorze %d\n", KOLEJKA_NAZWA, serwer);
		printf ("mq_flags: = %ld\n", atrybuty.mq_flags);
		printf ("mq_maxmsg: = %ld\n", atrybuty.mq_maxmsg);
		printf ("mq_msgsize: = %ld\n", atrybuty.mq_msgsize);
		printf ("mq_curmsgs: = %ld\n\n", atrybuty.mq_curmsgs);
	}
	
	if (atexit (wyjscie) != 0) // zamkniecie kolejki przed zakonczeniem programu
	{
		perror("atexit error");
		_exit(EXIT_FAILURE);
	}
	
	if (signal (SIGINT,sygnal_wyjscie) == SIG_ERR) // obsługa przerwania
	{
		perror("Błąd signal");
		exit(EXIT_FAILURE);
	}
	
	srand(time(NULL));
	
	// czekaj losową ilość czasu
	sleep ((double)(rand() % (int)(max_dlugosc_czekania * 100)) / 100);
	
	while (1) 
	{
		
		printf ("Wpisz działanie\n");
		if (scanf ("%s", odczyt) == EOF) // ustawienie znaku konca pliku
		{
			
			printf ("\n==============================================================\n");
			printf ("Koniec odczytu :D\n");
			exit(EXIT_SUCCESS);
		}
		sprintf(string, "%d %s", getpid(), odczyt); // dopisywanie PID do komunikatu
		
		kolejka_wyslij(serwer, string, 1); // wysylanie zapytania do serwera
		printf ("\nWysłano zapytanie do serwera: %s\n", string);
		
		kolejka_odpowiedz = kolejka_utworz (kolejka_odpowiedz_nazwa, O_RDONLY); // utwórz kolejkę do odebrania odpowiedzi
		
		printf ("Oczekiwanie na odpowiedź z serwera\n");
		kolejka_odbierz (kolejka_odpowiedz, string, NULL); // czekanie na odpowiedz serwera przez wpisanie NULL, najniższy priorytet
		printf ("Odpowiedź z serwera: %s\n\n", string);
		
		kolejka_zamknij (kolejka_odpowiedz); // zamykanie kolejki do odpowiedzi
		kolejka_usun (kolejka_odpowiedz_nazwa); // usuwanie kolejki do odpowiedzi
		
		sleep ((double)(rand() % (int)(max_dlugosc_czekania * 100)) / 100); 
	}

	kolejka_zamknij (serwer); // zamykanie kolejki serwera
		
	printf ("\n\nKlient: koniec procesu\n");
	
	return 0;
}