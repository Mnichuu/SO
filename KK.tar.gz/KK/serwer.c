#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <time.h>
#include <mqueue.h>
#include "kolejki_komunikatow.h"

void wyjscie(void) // void do usuwania kolejki funkcja atexit
{
	kolejka_usun (KOLEJKA_NAZWA);
}

void sygnal_wyjscie(int signal) // void do wypisywania komunikatu przez funkcje signal
{
	printf ("\nSygnał przerwania, usuwanie kolejki\n");
	exit(EXIT_SUCCESS);
}

int main () 
{
	
	int PID_klienta;
	char string[DLUGOSC_KOMUNIKATU];
	int liczba1;
	int liczba2;
	char operator;
	int wynik;
	char wynik_s[DLUGOSC_KOMUNIKATU];
	mqd_t kolejka_desk;
	mqd_t odpowiedz;
	
	const double max_dlugosc_czekania = 2.0;
	
	kolejka_desk = kolejka_utworz (KOLEJKA_NAZWA, O_RDONLY); // tworzenie kolejki do odbierania z niej komunikatow, przez O_RDONLY
	
	//struktura atrybutów, flag, maksymalnego rozmiaru wiadomosci, rozmiar wiadomosci, liczba aktualnych zapytan w kolejce
	{
		struct mq_attr atrybuty = kolejka_pobierz_atrybuty (kolejka_desk);
		printf ("Utworzono kolejkę \"%s\" deskryptor %d o atrybutach:\n", KOLEJKA_NAZWA, kolejka_desk);
		printf ("mq_flags: = %ld\n", atrybuty.mq_flags);
		printf ("mq_maxmsg: = %ld\n", atrybuty.mq_maxmsg);
		printf ("mq_msgsize: = %ld\n", atrybuty.mq_msgsize);
		printf ("mq_curmsgs: = %ld\n\n", atrybuty.mq_curmsgs);
	}
	
	if (atexit (wyjscie) != 0) // usuwanie kolejki na koniec programu
	{
		perror("atexit error");
		exit(EXIT_FAILURE);
	}
	
	if (signal (SIGINT,sygnal_wyjscie) == SIG_ERR) // łapanie sygnału przerwania
	{
		perror("Błąd signal");
		exit(EXIT_FAILURE);
	}
	
	srand(time(NULL));
	
	while (1) 
	{
		
		kolejka_odbierz (kolejka_desk, string, NULL); 	// czytanie komunikatu z kolejki
		
		sscanf(string, "%d %d%c%d", &PID_klienta, &liczba1, &operator, &liczba2); // skanowanie tekstu wprowadzonego przez uzytkownika
		
		printf ("Odebrano zapytanie od %d - działanie %d %c %d\n", PID_klienta, liczba1, operator, liczba2);
		
		// wykonywanie obliczen
		
		if (operator == '+') 
		{
			wynik = liczba1 + liczba2;
			sprintf (wynik_s, "%d", wynik);
		} else if (operator == '-') {
			wynik = liczba1 - liczba2;
			sprintf (wynik_s, "%d", wynik);
		} else if (operator == '*') {
			wynik = liczba1 * liczba2;
			sprintf (wynik_s, "%d", wynik);
		} else if (operator == '/') {
			wynik = liczba1 / liczba2;
			sprintf (wynik_s, "%d", wynik);
		} 
		else 
		{
			sprintf (wynik_s, "Błąd: nieznany operator");
		}
		
		// czekaj losową ilość czasu
		sleep ((double)(rand() % (int)(max_dlugosc_czekania * 100)) / 100);
		
		sprintf (string, "/%d", PID_klienta);
		odpowiedz = kolejka_otworz (string, O_WRONLY); // otwieranie kolejki do wysłania komunikatu (odpowiedzi)
		
		// odpowiedz
		printf ("Wysyłanie odpowiedzi %s do procesu %d\n", wynik_s, PID_klienta);
		kolejka_wyslij (odpowiedz, wynik_s, 1);
		kolejka_zamknij (odpowiedz);
		//kolejka_usun (KOLEJKA_NAZWA);
	}
	
	kolejka_usun (KOLEJKA_NAZWA); // usuwanie kolejki
	
	printf ("\n\nSerwer: koniec procesu\n");
	
	return 0;
}